=============================================================================== 
                           xlt-proxy-recorder
                           Version: 1.2.2
===============================================================================
This application is mainly a web proxy that captures requests. 
The captured requests can be exported into different formats. You can create 
custom export templates to export the captured requests into required formats.


Contents
===============================================================================
  1.  Requirements - What else do I need to run this application?
  2.  Start - How to run this application?
  3.  Proxy Setup - How to capture something?
  3.1 HTTPS traffic - Why is the page not loaded or looks incomplete?
  4.  Capturing/Export - What I have to click now?
  5.  Editing Templates - How can I export to another format?
  6.  FAQ - What's going wrong?
  7.  3rd party - What was used to make this application?  


1. Requirements - What else do I need to run this application?
===============================================================================
Installed Java Runtime Environment (JRE) 7 or higher
You can download it from:
    http://java.com


2. Start - How to run this application?
===============================================================================
Execute one of the start scripts contained in the 'bin' folder according to
your operating system. This requires that the java command is accessible from
the command line.
  Windows - start.cmd
  UNIX like systems - start.sh

If the java command is not accessible or you want to start this application
with another JRE use the following command on a command line.

  "<java_path>" -jar "<application_folder>/lib/xlt-proxy-recorder-1.2.2.jar"

  Replace <..> as following:
    <java_path> - The path to the java executable
    <application_folder> - The path to the folder containing this readme file


3. Proxy Setup - How to capture something?
===============================================================================
As this application is a web proxy you need to specify this proxy in your web 
client to capture its requests. The default port used by this proxy is 9090.
You can change the port at the settings dialog of this application.

Example:
  Firefox - Go to the Preferences -> Advanced -> Network -> "Connection" Settings
        Select "Manual proxy configuration"
        Fill "HTTP Proxy:" localhost "Port:" 9090
        Select "Use this proxy server for all protocols"
        Ensure that "No Proxy for:" does not contains localhost
        OK -> Close

3.1 HTTPS traffic - Why is the page not loaded or looks incomplete?
===============================================================================
To capture HTTPS traffic it could be necessary to use an authority certificate 
which allows the proxy to capture encrypted data. To create a certificate go to
the ProxyRecorder settings dialog. The created certificate must be then
configured as authority certificate in your browser.

Example:
  Firefox: - Go to Preferences -> Advanced -> Certificates
                        -> View Certificates -> Authorities
           Select "Import" to import the certificate
           Check "Trust this CA to identify websites"
           OK -> Close

4. Capturing/Export - What I have to click now?
===============================================================================
To start capturing click on the Start/Stop button.
Then let your web client generate requests. For example if you use a browser
just open web pages and brows as usual. You can pause and resume the capturing
at any time by clicking the Start/Stop button. 

You can add Actions to group requests together by clicking the Add Action 
button or you can add Comments by clicking the Add Comment button.

If your sequence is finally captured you can export it by clicking on the 
Export button. Select a format and a destination file and click on export.

You can add your own additional export formats. How to do this is described in 
a separate chapter.


5. Editing Templates - How can I export to another format?
===============================================================================
The template folder contains an "Export Demo.template" file which is intended
to be a starting point for own custom export templates.
Just copy, rename and and edit this file to let it generate your required
output format. The new template file must be placed into the "templates" folder
and must have the file ending ".template". The new template will occur in the
export dropdown.

The template is processed by FreeMarker.
Please take a look at the FreeMarker manual for more informations about
template editing.
    Template Author's Guide - http://freemarker.org/docs/dgui.html
    Reference - http://freemarker.org/docs/ref.html


6. FAQ - What's going wrong?
===============================================================================

Q: The browser complains about a bad certificate.

A: If the page is accessed via protocol HTTPS the browser has to break up the
certificate chain to record all the requests and records correctly. In this
case your browser might complain about the current certificate and you have
to allow it as an exception to get the page displayed.

-------------------------------------------------------------------------------

Q: Why does the resulting page looks odd in browser if proxy is in use?

A: If part of the site (JavaScript/CSS sources) are accessed via an HTTPS
secured connection and the corresponding URL is not traded as an exception yet
parts of the page might be not displayed correctly since the browser will not
load the files. Unfortunately most browsers do not inform the user about this.
In this case please identify the problematic JavaScript's/CSS's resources and
call the URL directly via the browsers address bar to handle the certificate
exception. When all secured connections of the necessary resources are
indentified and handled try to load your page again. This step is not necessary
for each single page or resource. URLs you have handled once will not cause the
browser to complain if the browser saved the decission.


7. 3rd party - What else was used to make this application?
===============================================================================
This software uses some additional open source software and resources. 
The licenses can be found in the doc/3rd-party folder.

The following projects are directly used:
    BrowserMob Proxy - lib/browsermob-proxy-2.0-beta-9.jar
    FreeMarker - lib/freemarker-2.3.20.jar
    JGoodies Forms - lib/jgoodies-forms-1.7.2.jar
    Tango Desktop Project - icons/*.png

