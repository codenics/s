'''

    In this package there are functions implemented which are copied from external sources.
    
    E.g. due to the lack of possibility to install (like the pretty cool czi ready from Christopher Gohlke)
    
    
    Make sure it is not possible to access this package from outside!
    
'''